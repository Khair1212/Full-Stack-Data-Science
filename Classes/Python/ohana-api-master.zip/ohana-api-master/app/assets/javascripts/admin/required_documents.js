$(document).ready(function() {
  $('#service_required_documents').select2();
});
