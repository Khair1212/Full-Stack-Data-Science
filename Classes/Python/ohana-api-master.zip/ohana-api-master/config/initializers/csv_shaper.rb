CsvShaper.configure do |config|
  config.header_inflector = :underscore
end
