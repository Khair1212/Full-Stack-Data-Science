module Exceptions
  class InvalidRadius < ArgumentError
  end

  class InvalidLatLon < ArgumentError
  end
end
